package br.com.caelum.argentum.ws.modelo;

public enum Quantidade {
	ZERO, UM, DOIS, TRES, QUARTO, CINCO, SEIS, SETE, OITO, NOVE, DEZ;
}
